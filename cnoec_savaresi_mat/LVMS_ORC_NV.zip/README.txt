LVMS_ORC_NV

track: Las Vegas Motor Speedway - Outside Road Course - North Variant

RefrencePoint: (Lat, Lon, Alt) of (0,0,0) point of Cartesian coordinate system
Inside: [x,y,z] coordinates of inner bound
Outside: [x,y,z] coordinates of outerbound
Centre: [x,y] coordinates of centerline
Racing: [x,y] coordinates of racing line